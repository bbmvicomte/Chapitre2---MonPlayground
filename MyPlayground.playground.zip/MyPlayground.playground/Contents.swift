import UIKit

var emojiDict = ["🇫🇷": "France", "🇵🇰": "Pakistan", "🇺🇸": "États-Unis", "🇧🇷": "Brésil", "🇵🇹": "Portugal"]
var motRecherche = "🇺🇸"
var signification = emojiDict[motRecherche]

let containerView = UIView(frame: CGRect(x: 0, y: 0, width: 300, height: 300))
containerView.backgroundColor = UIColor.red

let emojiLabel = UILabel(frame: CGRect(x: 95, y: 20, width: 150, height: 150))
emojiLabel.text = motRecherche
emojiLabel.font = UIFont.systemFont(ofSize: 100.0)

containerView.addSubview(emojiLabel)

let significationLabel = UILabel(frame: CGRect(x: 110, y: 100, width: 150, height: 150))
significationLabel.text = signification
significationLabel.font = UIFont.systemFont(ofSize: 30.0)
significationLabel.textColor = UIColor.white

containerView.addSubview(significationLabel)
